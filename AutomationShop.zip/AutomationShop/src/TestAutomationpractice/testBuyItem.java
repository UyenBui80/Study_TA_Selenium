package TestAutomationpractice;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class testBuyItem {
    WebDriver driver;
	@Before
	public void setUp() {
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
	}
	@Test
	public void testBuyItem() {
		// Scroll webpage
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.linkText("Printed Dress")));
		
		// Hover on item
		Actions actions = new Actions(driver);
		WebElement item = driver.findElement(By.linkText("Printed Dress"));
		actions.moveToElement(item);
		
		// Add item to Cart
		WebElement addToCart = driver.findElement(By.xpath("//ul[@id='homefeatured']//li[@class='ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-tablet-line first-item-of-mobile-line']//span[contains(text(),'Add to cart')]"));
		actions.moveToElement(addToCart);
		actions.click().build().perform();
		
		// Proceed to checkout
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement checkout = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proceed to checkout")));
		checkout.click();
		
		// SHOPPING-CART SUMMARY
		
		// 1. Summary
		checkout = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proceed to checkout")));
		checkout.click();
		
		// 2. Sign In tab
		DateFormat dateFormat = new SimpleDateFormat("ddHHmmss");
		Date date = new Date();
		String getTime= dateFormat.format(date);
		
		driver.findElement(By.id("email_create")).sendKeys("hiennd" + getTime + "@gmail.com" );
		driver.findElement(By.id("SubmitCreate")).click();
		
		// YOUR PERSONAL INFORMATION
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[contains(text(),'Your personal information')]")));
		
		if (!driver.findElement(By.id("id_gender1")).isSelected()) {
			driver.findElement(By.id("id_gender1")).click();
		}
		
		driver.findElement(By.id("customer_firstname")).sendKeys("Nguyen Duc");
		
		driver.findElement(By.id("customer_lastname")).sendKeys("Hien");
		
		driver.findElement(By.id("email")).clear();
		
		driver.findElement(By.id("email")).sendKeys("hiennd"+getTime+"@gmail.com");
		
		driver.findElement(By.id("passwd")).sendKeys("admin@123");
		
		driver.findElement(By.xpath("//select[@id='days']")).sendKeys("15");
		
		driver.findElement(By.xpath("//select[@id='months']")).sendKeys("April");
		
		driver.findElement(By.xpath("//select[@id='years']")).sendKeys("1993");
		
		if (!driver.findElement(By.id("newsletter")).isSelected()) {
			driver.findElement(By.id("newsletter")).click();
		}

		if (!driver.findElement(By.xpath("//input[@id='optin']")).isSelected()) {
			driver.findElement(By.xpath("//input[@id='optin']")).click();
		}
		// YOUR ADDRESS
		driver.findElement(By.id("address1")).sendKeys("Nam Tu Liem");
		
		driver.findElement(By.id("city")).sendKeys("Redondo");
		
		driver.findElement(By.xpath("//select[@id='id_state']")).sendKeys("Washington");
		
		driver.findElement(By.id("postcode")).sendKeys("98054");
		
		driver.findElement(By.id("id_country")).sendKeys("United States");
		
		driver.findElement(By.id("phone_mobile")).sendKeys("09633333333");
		
		driver.findElement(By.id("submitAccount")).click();
		
		// 3. ADDRESS tab
		WebElement processAddress = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("processAddress")));
		processAddress.click();
		
		// 4. SHIPPING tab
		if (!driver.findElement(By.id("cgv")).isSelected()) {
			driver.findElement(By.id("cgv")).click();
		}
		
		WebElement processCarrier = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("processCarrier")));
		processCarrier.click();
		
		// 5. PAYMENT tab
		driver.findElement(By.className("cheque")).click();
		WebElement confirm = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='button btn btn-default button-medium']")));
		confirm.click();
		
		// Verify message
		String expectedResult = "Your order on My Store is complete.";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='alert alert-success']")));
		String actualResult = driver.findElement(By.xpath("//p[@class='alert alert-success']")).getText();
		Assert.assertEquals(expectedResult, actualResult);
	}
	@After
	public void tearDown() {
		driver.close();
	}
}