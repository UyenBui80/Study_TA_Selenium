package TestAutomationpractice;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import com.sun.org.apache.bcel.internal.generic.Select;

public class BuyItem {
	WebDriver driver;
	@Before
	public void setUp(){
		// Open browser using Firefox
		System.getProperty("webdriver.gecko.driver","geckodriver.exe");
		driver = new FirefoxDriver();
		// Open web site
		driver.get("http://automationpractice.com/index.php");

	}
	// Search: Scroll Down + Selenium Web driver
	
		@Test
	public void buyItem() throws InterruptedException{ 
	// Using add on , Copy "Rel XPath"
		// Hover on product
		WebElement	product = driver.findElement(By.xpath("//ul[@id='homefeatured']//li[@class='ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-tablet-line first-item-of-mobile-line']"));
		Actions act = new Actions(driver);
        act.moveToElement(product).perform();
        // click button Add to Cart
        WebElement button_AddtoCart= driver.findElement(By.linkText("Add to cart"));		     
       //This will scroll the page till the element is found	
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView();", button_AddtoCart);
        button_AddtoCart.click();
        Thread.sleep(7000);
   
        // click button Proceed to checkout
        WebElement button_ProceedtoCheckout= driver.findElement(By.xpath("//span[contains(text(),'Proceed to checkout')]"));
        //WebElement button_ProceedtoCheckout= driver.findElement(By.linkText("Proceed to checkout"));
        button_ProceedtoCheckout.click();
        Thread.sleep(7000);
        
        // click button Proceed to checkout on Cart
        //WebElement button_ProceedtoCheckout2= driver.findElement(By.xpath("//a[@class='button btn btn-default standard-checkout button-medium']//span[contains(text(),'Proceed to checkout')]"));
        WebElement button_ProceedtoCheckout2= driver.findElement(By.linkText("Proceed to checkout"));
        button_ProceedtoCheckout2.click();        
        Thread.sleep(7000);
        
        //create account with email
        // Create username change with time
     	DateFormat dateFormat= new SimpleDateFormat("yyyyMMddHHmmss");
     	Calendar cal=Calendar.getInstance();
     	String GetDateTime= dateFormat.format(cal.getTime());
        // fill in email
        WebElement text_Email= driver.findElement(By.xpath("//input[@id='email_create']"));
        text_Email.sendKeys("uyenbui"+GetDateTime +"@test.com");
        // click button CreateanAccoun
        WebElement button_CreateanAccount= driver.findElement(By.xpath("//form[@id='create-account_form']//span[1]"));
        button_CreateanAccount.click();   
        Thread.sleep(7000);
        
        //Fill in Personal Information
        //Title Mrs
        WebElement radio_Title=driver.findElement(By.xpath("//input[@id='id_gender2']"));
        if (!radio_Title.isSelected()){
        	radio_Title.click();
        }
        //FirstName
        WebElement text_firstName= driver.findElement(By.xpath("//input[@id='customer_firstname']"));
        text_firstName.sendKeys("Uyen");
        //LastName
        WebElement text_LastName= driver.findElement(By.xpath("//input[@id='customer_lastname']"));
        text_LastName.sendKeys("Bui");   
        //Password
        WebElement text_Password= driver.findElement(By.xpath("//input[@id='passwd']"));
        text_Password.sendKeys("123456");          
       /*  //Select Date of Birth
        Select dd_day= new Select(driver.findElement(By.xpath("//select[@id='days']"));
        dd_day.clear();
        dd_day.selectByVisibleText("1");
        */
        
      //Fill in Address
        //FirstName
        WebElement text_firstName1= driver.findElement(By.xpath("//input[@id='firstname']"));
        text_firstName1.sendKeys("Uyen");
        //LastName
        WebElement text_LastName1= driver.findElement(By.xpath("//input[@id='lastname']"));
        text_LastName1.sendKeys("Bui"); 
        //Address
        WebElement text_Address= driver.findElement(By.xpath("//input[@id='address1']"));
        text_Address.sendKeys("Q7"); 
        //City
        WebElement text_City= driver.findElement(By.xpath("//input[@id='city']"));
        text_City.sendKeys("HCM"); 
        //State
        WebElement State = driver.findElement(By.xpath("//select[@id='id_state']"));
        State.sendKeys("Alabama");
        //Zipcode
        WebElement ZipCode = driver.findElement(By.xpath("//input[@id='postcode']"));
        ZipCode.sendKeys("70000");
        //Country
        WebElement Country = driver.findElement(By.xpath("//select[@id='id_country']"));
        Country.sendKeys("United States");
        //Mobile phone
        WebElement text_Mphone= driver.findElement(By.xpath("//input[@id='phone_mobile']"));
        text_Mphone.clear();
        text_Mphone.sendKeys("123456789"); 
        //Alias addr
        WebElement text_aliasMphone= driver.findElement(By.xpath("//input[@id='alias']"));
        text_aliasMphone.sendKeys("123456789"); 
        // click button Register
        WebElement button_Register= driver.findElement(By.xpath("//span[contains(text(),'Register')]"));
        button_Register.click();  
        Thread.sleep(7000);
        
        //
        // click button Proceed to checkout on Cart
        WebElement button_Proceedtocheckout= driver.findElement(By.xpath("//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]"));
        button_Proceedtocheckout.click();   
        Thread.sleep(7000);
        
        //
       //Agree to the Terms
        WebElement radio_Agree=driver.findElement(By.xpath("//label[contains(text(),'I agree to the terms of service and will adhere to')]"));
        if (!radio_Agree.isSelected()){
        	radio_Agree.click();
        }
        // click button Proceed to checkout on Cart
        WebElement button_Proceedtocheckout3= driver.findElement(By.xpath("//button[@name='processCarrier']//span[contains(text(),'Proceed to checkout')]"));
        button_Proceedtocheckout3.click();   
        Thread.sleep(7000);
        
        //
        // click button Proceed to checkout on Cart
        WebElement button_Paybycheck= driver.findElement(By.xpath("//a[@class='cheque']"));
        button_Paybycheck.click();   
        Thread.sleep(7000); 
        
        //
        // click button Proceed to checkout on Cart
        WebElement button_Confirm= driver.findElement(By.xpath("//span[contains(text(),'I confirm my order')]"));
        button_Confirm.click();   
        Thread.sleep(7000);        
        
        //
		// Verify Result
		String expectedResult  = "Your order on My Store is complete.";
		String actualResult = driver.findElement(By.xpath("//p[@class='alert alert-success']")).getText();
		Assert.assertEquals(expectedResult, actualResult);       
        
		}    
	@After
	public void tearDown(){
		driver.close();
	}
	


}
