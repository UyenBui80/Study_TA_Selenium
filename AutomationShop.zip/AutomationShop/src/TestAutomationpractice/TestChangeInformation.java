package TestAutomationpractice;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestChangeInformation {
WebDriver driver;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		// Open website
		driver.get("http://automationpractice.com/index.php");
	}

	@Test
	public void ChangeInformation() {
		
		//// TOP PAGE
		// Sign in button click		
		driver.findElement(By.xpath("//a[@class='login']")).click();
		
		// 2. Sign In tab
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("uyen133@test.com");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("123456");
		//set explicit Wait 
		WebDriverWait	wait20 = new WebDriverWait(driver, 20);
		WebElement submitButton= wait20.until(ExpectedConditions.
						visibilityOfElementLocated(By.id("SubmitLogin")));
		submitButton.click();
		
		//// MY ACCOUNT
		// My Personal Information 
		// click to Button [My personal information]
		WebDriverWait	wait100 = new WebDriverWait(driver, 100);
		WebElement submitInfo= wait100.until(ExpectedConditions.
						visibilityOfElementLocated(By.xpath("//span[contains(text(),'My personal information')]")));
		submitInfo.click();

		
		//// YOUR PERSONAL INFORMATION
		//Change FirstName
		WebElement text_1stName = driver.findElement(By.xpath("//input[@id='firstname']"));
		text_1stName.clear();
		text_1stName.sendKeys("Diem");
		
		//Change LastName
		WebElement text_lastName = driver.findElement(By.xpath("//input[@id='lastname']"));
		text_lastName.clear();
		text_lastName.sendKeys("Nguyen");
		
		// Current Password  
		WebElement text_currentPass = driver.findElement(By.xpath("//input[@id='old_passwd']"));
		text_currentPass.clear();
		text_currentPass.sendKeys("123456");
			
		//New Password  
		WebElement text_newPass = driver.findElement(By.xpath("//input[@id='passwd']"));
		text_newPass.clear();
		text_newPass.sendKeys("654321");

		
		// Confirm new Password 
		// Scroll webpage
		WebElement text_confirmPass = driver.findElement(By.xpath("//input[@id='confirmation']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", text_confirmPass);
		// Confirm new Password 
		text_confirmPass.clear();
		text_confirmPass.sendKeys("654321");	
		
		// Signed up for new letter
		WebElement check_signup = driver.findElement(By.xpath("//form[@class='std']//fieldset"));
		if (!check_signup.isSelected()){
			check_signup.click();
        }
		
		// Save
		WebElement saveButton= wait20.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));
		saveButton.click();
		
		// Verify bought product  in history
		String expectedResult 	= "Your personal information has been successfully updated.";
		//set explicit Wait 
		//WebDriverWait	wait10 = new WebDriverWait(driver, 10);
		WebElement element = wait20.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//p[@class='alert alert-success']")));
		String actualResult	= element.getText();
		Assert.assertEquals(expectedResult, actualResult);
			
	}
	
	@After
	public void tearDown(){
		// back to account to return old pass  
		driver.findElement(By.xpath("//span[contains(text(),'Diem Nguyen')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'My personal information')]")).click();

		//set explicit Wait 
		WebDriverWait	wait20 = new WebDriverWait(driver, 20);
		WebElement text_1stName = wait20.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//input[@id='firstname']")));
		//Return FirstName
		text_1stName.clear();
		text_1stName.sendKeys("Uyen");
		
		//Return LastName
		WebElement text_lastName = driver.findElement(By.xpath("//input[@id='lastname']"));
		text_lastName.clear();
		text_lastName.sendKeys("Bui");
		
		// Return Password  
		WebElement text_currentPass = driver.findElement(By.xpath("//input[@id='old_passwd']"));
		text_currentPass.clear();
		text_currentPass.sendKeys("654321");
			
		//Return Password  
		WebElement text_newPass = driver.findElement(By.xpath("//input[@id='passwd']"));
		text_newPass.clear();
		text_newPass.sendKeys("123456");

		
		// Return new Password 
		// Scroll webpage
		WebElement text_confirmPass = driver.findElement(By.xpath("//input[@id='confirmation']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", text_confirmPass);
		// Confirm new Password 
		text_confirmPass.clear();
		text_confirmPass.sendKeys("123456");	
		
		// Save
		WebElement saveButton= wait20.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));
		saveButton.click();
		
		driver.close();
	}
}
