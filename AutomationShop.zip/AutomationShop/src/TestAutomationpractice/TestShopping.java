package TestAutomationpractice;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestShopping {
    WebDriver driver;
	Actions actions;
	WebDriverWait wait;

	@Before
	public void setUp() {
		// Open web browser
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();		
		// setup actions
		actions = new Actions(driver);
		// setup wait
		wait = new WebDriverWait(driver, 20);
		// Go to website
		driver.get("http://automationpractice.com/index.php");
	}

	@Test
	public void testShopping() {
		WebElement targetItem = driver.findElement(By.xpath(
				"//ul[@id='homefeatured']//li[@class='ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-mobile-line']"));
		// scroll to target item
		JavascriptExecutor scroll = (JavascriptExecutor) driver;
		scroll.executeScript("arguments[0].scrollIntoView(true)", targetItem);

		// hover on target item
		actions.moveToElement(targetItem).perform();

		// click on [Add to cart] button
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
				"//ul[@id='homefeatured']//li[@class='ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-mobile-line hovered']//span[contains(text(),'Add to cart')]")));
		driver.findElement(By.xpath(
				"//ul[@id='homefeatured']//li[@class='ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-mobile-line hovered']//span[contains(text(),'Add to cart')]"))
				.click();

		// Click on [Proceed to checkout] button
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proceed to checkout")));
		driver.findElement(By.linkText("Proceed to checkout")).click();

		// SHOPPING-CART SUMMARY
		// Click on [Proceed to checkout] button
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proceed to checkout")));
		driver.findElement(By.linkText("Proceed to checkout")).click();

		// CREATE AN ACCOUNT
		// Add Date & time to user name and email
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar cal = Calendar.getInstance();
		String getDateTime = dateFormat.format(cal.getTime());
		// input email
		driver.findElement(By.id("email_create")).clear();
		driver.findElement(By.id("email_create")).sendKeys("hoadc" + getDateTime + "@123.com");

		// click [Create an account] button
		driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();

		// YOUR PERSONAL INFORMATION
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//h3[contains(text(),'Your personal information')]")));
		// Title
		driver.findElement(By.id("id_gender1")).click();
		// First Name
		driver.findElement(By.id("customer_firstname")).sendKeys("Hoa");
		// Last Name
		driver.findElement(By.id("customer_lastname")).sendKeys("Cao");
		// Password
		driver.findElement(By.id("passwd")).sendKeys("Aa@123456");
		// Date of Birth
		driver.findElement(By.id("days")).sendKeys("1");
		driver.findElement(By.id("months")).sendKeys("January");
		driver.findElement(By.id("years")).sendKeys("2000");
		// Sign up for our newsletter!
		driver.findElement(By.id("uniform-newsletter")).click();
		// Receive special offers from our partners!
		driver.findElement(By.id("uniform-optin")).click();
		// YOUR ADDRESS
		// Company
		driver.findElement(By.id("company")).sendKeys("Company");
		// Address
		driver.findElement(By.id("address1")).sendKeys("Da Nang");
		// City
		driver.findElement(By.id("city")).sendKeys("Da Nang");
		// State
		driver.findElement(By.id("id_state")).sendKeys("Florida");
		// Zip code
		driver.findElement(By.id("postcode")).sendKeys("55000");
		// Country
		driver.findElement(By.id("id_country")).sendKeys("United States");
		// Mobile phone
		driver.findElement(By.id("phone_mobile")).sendKeys("0392392392");
		// Assign an address alias for future reference.
		driver.findElement(By.id("alias")).clear();
		driver.findElement(By.id("alias")).sendKeys("32 characters");
		// Click [Register] button
		driver.findElement(By.id("submitAccount")).click();

		// ADDRESS
		// Click on [Proceed to checkout] button
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]")));
		driver.findElement(By.xpath("//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]"))
				.click();

		// SHIPPING
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("processCarrier")));
		// Terms of service
		driver.findElement(By.xpath("//label[contains(text(),'I agree to the terms of service and will adhere to')]"))
				.click();
		// Click on [Proceed to checkout] button
		driver.findElement(By.name("processCarrier")).click();

		// Click Pay by check
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cheque")));
		driver.findElement(By.className("cheque")).click();

		// Click Confirm
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(text(),'I confirm my order')]")));
		driver.findElement(By.xpath("//span[contains(text(),'I confirm my order')]")).click();

		// Verify message
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='alert alert-success']")));
		String expectedMessage = "Your order on My Store is complete.";
		String actualMessage = driver.findElement(By.xpath("//p[@class='alert alert-success']")).getText();

		Assert.assertEquals(expectedMessage, actualMessage);

	}

	@After
	public void tearDown() {
		driver.close();
	}

}