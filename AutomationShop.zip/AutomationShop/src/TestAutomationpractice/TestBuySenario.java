package TestAutomationpractice;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestBuySenario {

	WebDriver driver;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		// Open website
		driver.get("http://automationpractice.com/index.php");
	}

	@Test
	public void BuySenario() {
		
		//// TOP PAGE
		// Input Search keyword
		WebElement text_search = driver.findElement(By.xpath("//input[@id='search_query_top']"));
		text_search.clear();
		text_search.sendKeys("Blouse");
		// Search key press
		driver.findElement(By.xpath("//button[@name='submit_search']")).click();
		
		//wait for result
		WebElement product= driver.findElement(By.xpath("//a[@class='product_img_link']//img[@class='replace-2x img-responsive']"));
		// Hover on product
		Actions act = new Actions(driver);
		act.moveToElement(product).perform();
		
		// click on [Add to cart]
		//For Scroll
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//span[contains(text(),'Add to cart')]")));
		driver.findElement(By.xpath("//span[contains(text(),'Add to cart')]")).click();
		
		///CHECK OUT DIALOG
		// Proceed to checkout
		//set explicit Wait 
		WebDriverWait	wait15 = new WebDriverWait(driver, 15);
		WebElement checkout = wait15.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//span[contains(text(),'Proceed to checkout')]")));
		checkout.click();
		
		
		///SHOPPING-CART SUMMARY PAGE
		// 1. Summary Tab
		// Scroll web page
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.linkText("Proceed to checkout")));
		// Proceed to checkout
		driver.findElement(By.linkText("Proceed to checkout")).click();

		// 2. Sign In tab
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("uyen133@test.com");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("123456");
		//set explicit Wait 
		WebDriverWait	wait20 = new WebDriverWait(driver, 20);
		WebElement submitButton= wait20.until(ExpectedConditions.
						visibilityOfElementLocated(By.id("SubmitLogin")));
		submitButton.click();
		
		// 3. Address Tab
		// Scroll 
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.name("processAddress")));	
		driver.findElement(By.name("processAddress")).click();

		//4. Shipping
		WebElement checkbox_agree= driver.findElement(By.xpath("//label[contains(text(),'I agree to the terms of service and will adhere to')]"));
		if (!checkbox_agree.isSelected()) {
			checkbox_agree.click();
		}		
		
		driver.findElement(By.xpath("//button[@name='processCarrier']//span")).click();
				
		//5. Payment
		driver.findElement(By.xpath("//a[@class='cheque']//span")).click();
		
		//CHECK PAYMENT
		driver.findElement(By.xpath("//span[contains(text(),'I confirm my order')]")).click();
		
		// Verify Buying Complele
		String buy_suceed_expect = "Your order on My Store is not complete.";
		WebElement buy_succeed = wait20.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//p[@class='alert alert-success']")));
		String buy_suceed_actual = buy_succeed.getText();
		Assert.assertEquals(buy_suceed_expect, buy_suceed_actual);
		
		
		//ORDER CONFIRMATION
		driver.findElement(By.xpath("//span[contains(text(),'Uyen Bui')]")).click();
		
		// MY ACC -> ORDER History
		driver.findElement(By.xpath("//span[contains(text(),'Order history and details')]")).click();
			
		//ORDER HISTORY Details
		driver.findElement(By.xpath("//tr[contains(@class,'first_item')]//span[contains(text(),'Details')]")).click();
			

		// Verify bought product  in history
		String expectedResult 	= "Blouse - Color : Black, Size : S";
		//set explicit Wait 
		WebDriverWait	wait10 = new WebDriverWait(driver, 10);
		WebElement element = wait10.until(ExpectedConditions.
				visibilityOfElementLocated(By.xpath("//label[contains(text(),'Blouse - Color : Black, Size : S')]")));
		String actualResult	= element.getText();
		Assert.assertEquals(expectedResult, actualResult);
			
	}
	
	@After
	public void tearDown(){
		driver.close();
	}
	
}
